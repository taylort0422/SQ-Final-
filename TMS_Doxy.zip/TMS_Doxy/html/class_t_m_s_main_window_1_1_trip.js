var class_t_m_s_main_window_1_1_trip =
[
    [ "DestinationCity", "class_t_m_s_main_window_1_1_trip.html#a74b3bea311c1b0f4ef1947456cb3da34", null ],
    [ "DestinationDepotID", "class_t_m_s_main_window_1_1_trip.html#a9b8f0dfd3806ab59fd881c66892ca86a", null ],
    [ "GrossCost", "class_t_m_s_main_window_1_1_trip.html#a419602e661a5c35040e53bc06b991186", null ],
    [ "Hours", "class_t_m_s_main_window_1_1_trip.html#a27b7a209549170cbe69ebc101d180b11", null ],
    [ "ID", "class_t_m_s_main_window_1_1_trip.html#ab3ed3723d49bf74e82b46bee78041024", null ],
    [ "Kilometers", "class_t_m_s_main_window_1_1_trip.html#a22bd16abf0d799a578a0d8a064723984", null ],
    [ "OrderId", "class_t_m_s_main_window_1_1_trip.html#a2da1c2e5bf6e4eaa07e6b53414949fbf", null ],
    [ "OriginCity", "class_t_m_s_main_window_1_1_trip.html#a2a8799fbb2820ad28e9ae6e22c442464", null ],
    [ "OriginDepotID", "class_t_m_s_main_window_1_1_trip.html#a9474111c3a49ac2bb0a5b519373270a6", null ],
    [ "TripCost", "class_t_m_s_main_window_1_1_trip.html#a251615d9c5b93d75dd9dcea732d1c989", null ],
    [ "TruckId", "class_t_m_s_main_window_1_1_trip.html#adf292412d39f9b54f5ac278b05570c70", null ]
];