var annotated_dup =
[
    [ "TMSMainWindow", "namespace_t_m_s_main_window.html", [
      [ "AdminMainWindow", "class_t_m_s_main_window_1_1_admin_main_window.html", "class_t_m_s_main_window_1_1_admin_main_window" ],
      [ "App", "class_t_m_s_main_window_1_1_app.html", null ],
      [ "BuyerMainWindow", "class_t_m_s_main_window_1_1_buyer_main_window.html", "class_t_m_s_main_window_1_1_buyer_main_window" ],
      [ "Carrier", "class_t_m_s_main_window_1_1_carrier.html", "class_t_m_s_main_window_1_1_carrier" ],
      [ "CommTMS", "class_t_m_s_main_window_1_1_comm_t_m_s.html", "class_t_m_s_main_window_1_1_comm_t_m_s" ],
      [ "Communicate", "class_t_m_s_main_window_1_1_communicate.html", "class_t_m_s_main_window_1_1_communicate" ],
      [ "Contract", "class_t_m_s_main_window_1_1_contract.html", "class_t_m_s_main_window_1_1_contract" ],
      [ "Order", "class_t_m_s_main_window_1_1_order.html", "class_t_m_s_main_window_1_1_order" ],
      [ "PlannerMainWindow", "class_t_m_s_main_window_1_1_planner_main_window.html", "class_t_m_s_main_window_1_1_planner_main_window" ],
      [ "RoleSelectWindow", "class_t_m_s_main_window_1_1_role_select_window.html", "class_t_m_s_main_window_1_1_role_select_window" ],
      [ "Trip", "class_t_m_s_main_window_1_1_trip.html", "class_t_m_s_main_window_1_1_trip" ]
    ] ],
    [ "Comm", "class_comm.html", null ]
];