var files_dup =
[
    [ "AdminMainWindow.xaml.cs", "_admin_main_window_8xaml_8cs.html", [
      [ "TMSMainWindow.AdminMainWindow", "class_t_m_s_main_window_1_1_admin_main_window.html", "class_t_m_s_main_window_1_1_admin_main_window" ]
    ] ],
    [ "App.xaml.cs", "_app_8xaml_8cs.html", [
      [ "TMSMainWindow.App", "class_t_m_s_main_window_1_1_app.html", null ]
    ] ],
    [ "BuyerMainWindow.xaml.cs", "_buyer_main_window_8xaml_8cs.html", [
      [ "TMSMainWindow.BuyerMainWindow", "class_t_m_s_main_window_1_1_buyer_main_window.html", "class_t_m_s_main_window_1_1_buyer_main_window" ]
    ] ],
    [ "Carrier.cs", "_carrier_8cs.html", [
      [ "TMSMainWindow.Carrier", "class_t_m_s_main_window_1_1_carrier.html", "class_t_m_s_main_window_1_1_carrier" ]
    ] ],
    [ "CommTMS.cs", "_comm_t_m_s_8cs.html", [
      [ "TMSMainWindow.CommTMS", "class_t_m_s_main_window_1_1_comm_t_m_s.html", "class_t_m_s_main_window_1_1_comm_t_m_s" ]
    ] ],
    [ "Communicate.cs", "_communicate_8cs.html", [
      [ "TMSMainWindow.Communicate", "class_t_m_s_main_window_1_1_communicate.html", "class_t_m_s_main_window_1_1_communicate" ]
    ] ],
    [ "Contract.cs", "_contract_8cs.html", [
      [ "TMSMainWindow.Contract", "class_t_m_s_main_window_1_1_contract.html", "class_t_m_s_main_window_1_1_contract" ]
    ] ],
    [ "mainwindow.xaml.cs", "mainwindow_8xaml_8cs.html", [
      [ "TMSMainWindow.RoleSelectWindow", "class_t_m_s_main_window_1_1_role_select_window.html", "class_t_m_s_main_window_1_1_role_select_window" ]
    ] ],
    [ "Order.cs", "_order_8cs.html", [
      [ "TMSMainWindow.Order", "class_t_m_s_main_window_1_1_order.html", "class_t_m_s_main_window_1_1_order" ]
    ] ],
    [ "PlannerMainWindow.xaml.cs", "_planner_main_window_8xaml_8cs.html", [
      [ "TMSMainWindow.PlannerMainWindow", "class_t_m_s_main_window_1_1_planner_main_window.html", "class_t_m_s_main_window_1_1_planner_main_window" ]
    ] ],
    [ "TMSMainPage.h", "_t_m_s_main_page_8h.html", null ],
    [ "Trip.cs", "_trip_8cs.html", [
      [ "TMSMainWindow.Trip", "class_t_m_s_main_window_1_1_trip.html", "class_t_m_s_main_window_1_1_trip" ]
    ] ]
];