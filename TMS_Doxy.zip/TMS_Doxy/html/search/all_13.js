var searchData=
[
  ['vantype_0',['vanType',['../class_t_m_s_main_window_1_1_order.html#a4e752af83a43a722d46c2ea223f6438c',1,'TMSMainWindow::Order']]],
  ['vantype_1',['VanType',['../class_t_m_s_main_window_1_1_contract.html#acb6cf164681cfcd7d5dd6937f1ddccb8',1,'TMSMainWindow::Contract']]]
];
