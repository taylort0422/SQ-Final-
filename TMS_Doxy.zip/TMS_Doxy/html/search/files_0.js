var searchData=
[
  ['adminmainwindow_2examl_2ecs_0',['AdminMainWindow.xaml.cs',['../_admin_main_window_8xaml_8cs.html',1,'']]],
  ['app_2examl_2ecs_1',['App.xaml.cs',['../_app_8xaml_8cs.html',1,'']]]
];
