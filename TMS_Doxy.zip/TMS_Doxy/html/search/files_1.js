var searchData=
[
  ['buyermainwindow_2examl_2ecs_0',['BuyerMainWindow.xaml.cs',['../_buyer_main_window_8xaml_8cs.html',1,'']]]
];
