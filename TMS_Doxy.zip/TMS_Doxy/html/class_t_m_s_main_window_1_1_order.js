var class_t_m_s_main_window_1_1_order =
[
    [ "Order", "class_t_m_s_main_window_1_1_order.html#a5d2feca871caca7faf8737f317dcbc19", null ],
    [ "CalcTotalHours", "class_t_m_s_main_window_1_1_order.html#a24ffee555987b9f69ce3c20ffa13cfa5", null ],
    [ "ToString", "class_t_m_s_main_window_1_1_order.html#a8b9252bb8bb00ce34f444503a6847a8d", null ],
    [ "tripList", "class_t_m_s_main_window_1_1_order.html#a68f74b62f895ba35619c11bb6dbe869d", null ],
    [ "Confirmed", "class_t_m_s_main_window_1_1_order.html#a5f68c1ce23d6de9227324af123bebd9d", null ],
    [ "CustomerID", "class_t_m_s_main_window_1_1_order.html#a26ad20ae4b80bc549fcfa2b4f80ae254", null ],
    [ "CustomerName", "class_t_m_s_main_window_1_1_order.html#ac5f9c2c262b60d61dde833c668649b36", null ],
    [ "date", "class_t_m_s_main_window_1_1_order.html#a774480dd6d2b84f80f7c18537260ad75", null ],
    [ "DestinationCity", "class_t_m_s_main_window_1_1_order.html#aa69bedf62cb93d4e3004ac599369e049", null ],
    [ "Id", "class_t_m_s_main_window_1_1_order.html#a3c92f14fcbafdc0ac910c3ea5514524b", null ],
    [ "JobType", "class_t_m_s_main_window_1_1_order.html#aaa4642f331622e6690ab78a04b6dfd8e", null ],
    [ "Markup", "class_t_m_s_main_window_1_1_order.html#acd02a464d61ddec615dd67992aa64025", null ],
    [ "OriginCity", "class_t_m_s_main_window_1_1_order.html#a814cfd21e69f588c282d00e5238c6851", null ],
    [ "Surcharge", "class_t_m_s_main_window_1_1_order.html#a153a6b7e574090419e677630bc44d862", null ],
    [ "TotalCost", "class_t_m_s_main_window_1_1_order.html#ac6c64dc070ffbfc406fd614d19f17343", null ],
    [ "TotalHours", "class_t_m_s_main_window_1_1_order.html#a37ee77db72ca99e7b2a3bb0e56064251", null ],
    [ "TotalKms", "class_t_m_s_main_window_1_1_order.html#a24e55d20d69c3877e576cee680bcb6f0", null ],
    [ "vanType", "class_t_m_s_main_window_1_1_order.html#a4e752af83a43a722d46c2ea223f6438c", null ]
];