var class_t_m_s_main_window_1_1_communicate =
[
    [ "Communicate", "class_t_m_s_main_window_1_1_communicate.html#abe43ad9b47229f8bcb7777e361e881cf", null ],
    [ "RetrieveContracts", "class_t_m_s_main_window_1_1_communicate.html#a19eb594004b930935448078d2890a461", null ],
    [ "DbIP", "class_t_m_s_main_window_1_1_communicate.html#aba5a2f550e3b505dc550b242e6a67627", null ],
    [ "DbName", "class_t_m_s_main_window_1_1_communicate.html#a8f4b006365927d49dbd226bc29b9cfc1", null ],
    [ "DbPassword", "class_t_m_s_main_window_1_1_communicate.html#acdc8fe131e431e5315b448b23b22e29d", null ],
    [ "DbPort", "class_t_m_s_main_window_1_1_communicate.html#a3a101124c5070f67bdcc148f3a3093b5", null ],
    [ "DbUser", "class_t_m_s_main_window_1_1_communicate.html#abc7531dabe10ed197f4c6e5c3112f46f", null ]
];